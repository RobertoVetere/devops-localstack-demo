package com.robedev.springboot_localstack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootLocalstackApplicationTests {

	@Test
	void contextLoads() {
	}

}
