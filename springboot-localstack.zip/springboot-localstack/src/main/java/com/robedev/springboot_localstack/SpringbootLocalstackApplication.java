package com.robedev.springboot_localstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootLocalstackApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootLocalstackApplication.class, args);
	}

}
